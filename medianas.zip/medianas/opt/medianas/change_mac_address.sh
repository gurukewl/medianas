#!/bin/sh
chmod +666 /etc/smsc95xx_mac_addr
