# Questions / Ideas concerning the Max2Play API?
Use the Max2Play forum for requests and bug reports.


