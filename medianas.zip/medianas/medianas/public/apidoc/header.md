# Preamble
The Max2Play API is work in progress:
 - new functions will be released on request by users
 
This document offers instructions on how to use the Max2Play web service to access and control data via http requests.